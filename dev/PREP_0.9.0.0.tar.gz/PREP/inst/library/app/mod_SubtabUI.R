#' {{MODULE_ID}} shiny UI
#'
#' @return {{MODULE_ID}} UI
#'
#' @import shinyBS
#' @import shinydashboardPlus
#'
{{MODULE_ID}}UI <- function( id="{{MODULE_ID}}"  )
{
    ns <- NS(id)
    lRet <-  list( )
    return( lRet )
}
