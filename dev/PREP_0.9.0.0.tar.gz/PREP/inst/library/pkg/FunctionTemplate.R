#################################################################################################### .
#   Program/Function Name:
#   Author: Author Name
#   Description: {{FILE_DESCRIPTION}}
#   Change History:
#   Last Modified Date: {{CREATION_DATE}}
#################################################################################################### .
#' @name {{FUNCTION_NAME}}
#' @title {{FUNCTION_NAME}}
#' @description { Description: {{FILE_DESCRIPTION}} }
#' @export
{{FUNCTION_NAME}} <- function( [Add arguments] )
{

    lRet <- list( )  #Example of return object
    return( lRet )   # Use an explicit return
}
