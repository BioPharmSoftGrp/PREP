#################################################################################################### .
#   Program/Function Name:
#   Author: Author Name
#   Description: Test file for {{FILE_NAME}}
#   Change History:
#   Last Modified Date: {{CREATION_DATE}}
#################################################################################################### .


context( "{{FUNCTION_NAME}}")

test_that("Test- {{FUNCTION_NAME}}", {
    # Example test that will fail
    # nRet         <- 1
    # nExpectedRet <- 10


    # expect_equal( nRet, nExpectedRet, info = "The test failed...", label ="Test for ..." )
})
