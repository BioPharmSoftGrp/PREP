library(testthat)
library(GCalculations)

test_check("GCalculations")
