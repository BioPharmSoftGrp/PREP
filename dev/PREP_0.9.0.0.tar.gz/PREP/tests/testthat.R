library(testthat)
library(PREP)

test_check("PREP")
