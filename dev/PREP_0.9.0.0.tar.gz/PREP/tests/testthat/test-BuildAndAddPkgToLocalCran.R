#################################################################################################### .
#   Program/Function Name:
#   Author: Author Name
#   Description: Test file for BuildAndAddPkgToLocalCran
#   Change History:
#   Last Modified Date: 12/04/2020
#################################################################################################### .


context( "BuildAndAddPkgToLocalCran")

test_that("Test- BuildAndAddPkgToLocalCran", {
    # Example test that will fail
    # nRet         <- 1
    # nExpectedRet <- 10


    # expect_equal( nRet, nExpectedRet, info = "The test failed...", label ="Test for ..." )
})
