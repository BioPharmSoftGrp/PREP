#################################################################################################### .
#   Program/Function Name:
#   Author: Author Name
#   Description: Test file for CreateAppStandaloneFromProjectCreation
#   Change History:
#   Last Modified Date: 10/01/2020
#################################################################################################### .


context( "CreateAppStandaloneFromProjectCreation")

test_that("Test- CreateAppStandaloneFromProjectCreation", {
    # Example test that will fail
    # nRet         <- 1
    # nExpectedRet <- 10


    # expect_equal( nRet, nExpectedRet, info = "The test failed...", label ="Test for ..." )
})
