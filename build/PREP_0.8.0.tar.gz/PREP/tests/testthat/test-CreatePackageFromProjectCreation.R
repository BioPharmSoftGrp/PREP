#################################################################################################### .
#   Program/Function Name:
#   Author: Author Name
#   Description: Test file for CreatePackageFromProjectCreation
#   Change History:
#   Last Modified Date: 10/01/2020
#################################################################################################### .


context( "CreatePackageFromProjectCreation")

test_that("Test- CreatePackageFromProjectCreation", {
    # Example test that will fail
    # nRet         <- 1
    # nExpectedRet <- 10


    # expect_equal( nRet, nExpectedRet, info = "The test failed...", label ="Test for ..." )
})
