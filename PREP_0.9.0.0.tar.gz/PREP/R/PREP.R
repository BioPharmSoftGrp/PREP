#' PREP
#'
#' The PREP package was developed to create Shiny projects based on a tempalte and a R package, with testthat unit testing already setup, where
#' the Shiny app utiizes the R package.
#'
#' @docType package
#' @name PREP
"_PACKAGE"
